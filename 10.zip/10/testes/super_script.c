#include <stdio.h>

int main(int argc, char const *argv[]) {
  int k=0;
  for(int i = 1; i < 100; i++) {
    k+=i;
    printf("3 %d\n",i);
  }
  for(int i = 1; i < 100; i++) {
    printf("3 %d\n",-i);
  }
  printf("3\n");
  return 0;
}
