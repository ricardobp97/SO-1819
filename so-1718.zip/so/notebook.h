 #define CMD 1
 #define RES 2
 #define TXT 3

typedef struct sNotebook{
	char* linha; 			  //Identifica a linha do notebook contida nesta célula
	int tipo;	 			  //Indica o tipo desta célula, i.e., se se trata de documentação, comando ou resultado de um comando
	int tamanho; 			  //Tamanho da linha
	int in; 				  //stdin deste comando corresponde ao 'in'-ésimo comando anterior do notebook. in = 0 -> stdin
	int av;					  //p/comandos, ter em conta a partir de onde consideramos parte para execução = nº de dígitos de in + 2 ; ($n|)
	struct sNotebook *cmdAnt; //Se esta célula é a de um comando, terá um apontador para o comando anterior. Caso contrário será NULL

	struct sNotebook *prox;
}Notebook;

//Funções auxiliares para gestão do notebook
//Criação de um novo nodo
Notebook *novoNodo(char* linha, int tipo, int tamanho, int in, int nd);
//Libertar memória associada a um nodo
void freeNodo(Notebook **nodo);
//Libertar a memória alocada para este notebook
void freeNotebook(Notebook **n);
//Insere um nodo no final do notebook
void insereNodo(Notebook **lista,Notebook*nodo);
//Imprime os conteúdos da lista
void printNotebook(Notebook **lista);

//Funções auxiliares ao processamento do notebook
//Lê uma linha
int readln(int fildes, char** b);
//Funciona como 'system' 
int mySystem(char* s);
//Recebe "$52|" e retorna 52 e coloca p = 4
int getIn(char* s, int* p);
//Imprime um notebook num ficheiro
void writeNB(Notebook* n, char* filename);