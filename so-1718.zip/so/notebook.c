#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include "notebook.h"

Notebook *novoNodo(char* linha, int tipo, int tamanho, int in, int nd){
	Notebook *new = malloc(sizeof(Notebook));

	new->linha = linha;
	new->tipo = tipo;
	new->tamanho = tamanho;
	new->in = in;
	new->av = nd;
	new->cmdAnt = NULL;
	new->prox = NULL;

	return new;
}

void freeNodo(Notebook **n){
	if(*n != NULL){
		free((*n)->linha);
	    free(*n);
	    *n = NULL;
	}
}

void freeNotebook(Notebook **lista){

	if (*lista != NULL) {
	    freeNotebook(&(*lista)->prox);
	    freeNodo(lista);
	}
}

void insereNodo(Notebook **lista,Notebook*nodo){
	Notebook * current = *lista;

	if(*lista==NULL) *lista = nodo;
    else{
    	while (current != NULL) {
	    	if(current->prox == NULL){
	    		current->prox = nodo;
	    		break ;
	    	}
	        current = current->prox;
	    }
	}
	
}


void printNotebook(Notebook **lista){
	Notebook * current = *lista;

  	while (current != NULL) {
    	printf("\ntipo %d  tamanho %d--------->", current->tipo,current->tamanho);
    	printf("%s", current->linha);
    	
    	if(current->tipo == CMD){
	    	printf("stdin: %d\n", current->in);
	    	printf("avançar: %d\n", current->av);
	    }

        current = current->prox;
	}
}

//Lê uma linha.
int readln(int fildes, char** b) {
	int n = 0, r = 0;
    int c = 0;
    int size = 20;
    
    (*b) = (char *)malloc(sizeof(char)*size);

    do{
        //Lemos um caracter
        r = read(fildes, (*b)+c, 1);
        if(r < 0){
        	//Erro na leitura
        	return (-1);
        }

        //Atualizamos o tamanho
        n += r;
        //Atualizamos a posição
        c++;

        //Se o número total de caracteres lidos excede o tamanho alocado para suportar a linha,
        //realocamos memória
        if(size == c) {
            size = size*2;
            (*b) = (char *) realloc((*b), size);
        }

    }while(r > 0 && (*b)[c-1] != '\n'); //Lemos até EOF ou terminamos de ler a linha, i.e., estarmos perante caractere '\n'

    if(c==0) (*b) = NULL;

    return n;
}

//Devolve o número de palavras de uma string
int contaPalavras(char* s){
	int c = 0, i = 0, N = strlen(s);


	while(i < N){
		if(s[i] == '\n' || s[i] == '\t' || s[i] == ' ') i++;
		else if(s[i] != ' '){
			while(i < N && s[i] != '\n' && s[i] != '\t' && s[i] != ' '){
				i++;
			}
			c++;
		}
	}

	return c;
}

//Funciona como 'system' da bash. Ex: transforma "ls -l" em { "ls", "-l", NULL} e executa
int mySystem(char* s){
	
	if(s[strlen(s)-1] == '\n') s[strlen(s)-1] = '\0'; //Desconsideramos o \n

	int l = contaPalavras(s);
	char *p[l];
	int i = 0;

	p[i] = strtok(s, " ");

	while( p[i] != NULL){
		i++;
		p[i] = strtok(NULL, " ");
	}

	return execvp(p[0], p);
}

//Recebe "$52|" e retorna 52 e coloca p = 4
int getIn(char* s, int* p){
	int N = strlen(s);

	int i = 2; 

	while(s[i] >= '0' && s[i] <= '9' && i < N)
		i++;

	*p = i + 1;

	s[0] = '\0';

	return atoi(s+1);
}

//Imprime um notebook num ficheiro
void writeNB(Notebook* n, char* filename){
	int w, res = 0;
	char abreRes[4] = ">>>\n";
	char fechaRes[4] = "<<<\n";

	int fd = open(filename, O_TRUNC | O_WRONLY, 0666);
	if(fd < 0){
		perror("Erro na abertura do ficheiro");
		_exit(-1);
	}

	while(n){

		//Abrimos a zona que contem o resultado do comando
		if(!res && n->tipo == RES){
			res = 1;
			write(fd, &abreRes, 4);
		}

		//Fechamos a zona que contem o resultado do comando
		else if(res && n->tipo != RES){
			res = 0;
			write(fd, &fechaRes, 4);
		}

		w = write(fd, n->linha, n->tamanho);

		if(w < 0){
			perror("Erro na escrita.\n");
			_exit(-1);
		}

		n = n->prox;
	}

	//Caso a ultima linha do notebook seja um resultado, temos de fechar
	if(res)
		write(fd, &fechaRes, 4);
}