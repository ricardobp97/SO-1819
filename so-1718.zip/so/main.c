#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h> 
#include <sys/wait.h> 
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include "notebook.h"

//Representa uma cópia do notebook recebido incialmente (excluindo a representação de comandos anteriores)
Notebook *nInic = NULL;
//Nome do ficheiro que representa o notebook
char* filename;

//Signal Handler para interrupções. Consideramos o notebook inicial
void sair(int sig){
	if(sig == SIGINT){
		//Retomamos o estado inicial do notebook
		writeNB(nInic, filename);
		//Libertamos memória associada à estrutura
		freeNotebook(&nInic);
		_exit(-1);
	}
}

int main(int argc, char** argv){
	//Representará o novo notebook
	Notebook *n = NULL;
	char* linha;
	int r, w;
	filename = argv[1];

	//Definimos 'sair' como signalhandler de SIGINT
	signal(SIGINT, sair);

	//Notebook a processar
	int fd = open(filename, O_RDONLY, 0666);
	if(fd < 0){
		perror("Erro na abertura do ficheiro");
		_exit(-1);
	}

	//Armazenar texto
	int type = TXT;
	int in; //De onde vem o input do comando
	int av; //p/comandos, ter em conta a partir de onde consideramos parte para execução = nº de dígitos de in + 2 ; ($n|)
	int delim = 1; //Indica se a linha processada é diferente dos delimitadores de resultado de comando
	Notebook *antC = NULL; //Comando mais recente
	Notebook *el; //Elemento da lista que acabamos de inserir

	while((r = readln(fd, &linha))){
		if(r < 0){
			perror("Erro na leitura.\n");
			_exit(-1);
		}

		//Reiniciamos variáveis
		if(type != RES) type = TXT;
		in = 0;
		av = 0;

		//Estamos perante um comando
		if(r > 0 && linha[0] == '$'){
			type = CMD;
			av++;
		}
		

		//Verificamos se indica RES
		else if(r == 4){
				if(!strcmp(">>>\n", linha)){
					delim = 0;
				 	type = RES;
				}

				if(!strcmp("<<<\n", linha)){
					delim = 0;
					type = TXT;
				} 
			}

		//Verificamos se existe pipeline para comando anterior
		if(type == CMD && r > 1 && linha[1] == '|'){
			in = 1;
			av++;
		}

		//Verificamos se para este comando vamos considerar como stdin resultados de comandos anteriores
		if(type == CMD && r > 1 && linha[1] >= '0' && linha[1] <= '9'){
			char *s = strdup(linha);
			//Se s = "$52| cmd arg1 ..." enviamos "$52|" à função
			in = getIn(strtok(s, " "), &av);
			free(s);
		}


		//Só armazenamos a linha se não se tratar de um delimitador
		if(delim){
			 el = novoNodo(linha, type, r, in, av);
			 //Armazenamos a nova linha do notebook
			 insereNodo(&n, el);
			 //Armazenamos uma cópia
			 insereNodo(&nInic, novoNodo(strdup(linha), type, r, in, av));

			 //Se inserimos um comando, é necessário ter um apontador para o comando anterior
			 if(type == CMD){
			 	el->cmdAnt = antC;
			 	//Este passa a ser o comando mais recente
			 	antC = el;
			 }
		}
		else delim = 1;

	}

	close(fd);

	//Reabrimos o notebook para escrita, descartando os conteúdos anteriores
	fd = open(filename, O_TRUNC | O_WRONLY, 0666);
	if(fd < 0){
		perror("Erro na abertura do ficheiro");
		_exit(-1);
	}

	//Processamento
	while(n){
		//Documentação
		if(n->tipo == TXT){
			w = write(fd, n->linha, n->tamanho);

			if(w < 0){
				perror("Erro na escrita");
				kill(getpid(), SIGINT);
			}
		}
		else{
			//Comandos
			Notebook* pos; //Apontador auxiliar 
			int status; //Estado de saída do filho
			int pCMD[2]; //Pipe auxiliar para suportar stdin de um comando anterior
			int f, d;
			
			//Se o comando já foi executado anteriormente
			if(n->prox && n->prox->tipo == RES){
				Notebook* pt = n->prox;

				//Descartamos o resultado anterior
				while(pt && pt->tipo == RES){
					pos = pt;
					pt = pt->prox; 
					freeNodo(&pos);
				}
				
				n->prox = pt;

			}

			//Se o comando tem stdin o resultado de um comando anterior
			Notebook* cAnt;
			int redirIn;
			if((redirIn = n->in > 0)){
				cAnt = n->cmdAnt;

				int i = n->in - 1;
				while(cAnt && i > 0){ 
					cAnt = cAnt->cmdAnt;
					i--;
				}

				if(i > 0 || (i == 0 && !cAnt)){
					perror("O n-ésimo comando anterior especificado excede o número de comandos");
					kill(getpid(), SIGINT);
				}

				//cAnt está posicionado na primeira linha do resultado do comando
				cAnt = cAnt->prox;

				//Consideramos um novo pipe 
				if(pipe(pCMD) < 0){
					perror("Erro na criação de um pipe anónimo");
					kill(getpid(), SIGINT);
				}

				//Escrevemos o resultado no pipe
				while(cAnt && cAnt->tipo == RES){
					w = write(pCMD[1], cAnt->linha, cAnt->tamanho);

					if(w < 0){
						perror("Erro na escrita");
						kill(getpid(), SIGINT);
					}

					cAnt = cAnt->prox;
				}
			
			}
			
			int p[2];
			if(pipe(p) < 0){
				perror("Erro na criação de um pipe anónimo");
				kill(getpid(), SIGINT);
			}

			f = fork();
			if(f < 0){
				perror("Erro na criação de um processo filho");
				kill(getpid(), SIGINT);
			}

			if(!f){
				//Fechamos descritores não utilizados
				close(p[0]);
				//Se o stdin vem de outro comando, redirecionamos o input
				if(redirIn){
					//Fechamos descritores não utilizados
					close(pCMD[1]);

					d = dup2(pCMD[0], 0);
					if(d < 0){
						perror("Erro na duplicação de um descritor");
						kill(getpid(), SIGINT);
					}
					close(pCMD[0]);
				}

				//Redirecionamos stdout
				d = dup2(p[1], 1);
				if(d < 0){
					perror("Erro na duplicação de um descritor");
					kill(getpid(), SIGINT);
				}
				close(p[1]);

				//Executa o comando
				int e = mySystem(n->linha + n->av); 
				if(e < 0){
					perror("Erro no execvp");
					kill(getpid(), SIGINT);
				}
			}
			else{
				//Fechamos descritores que não vamos utilizar
				close(p[1]);
				if(redirIn){
					close(pCMD[0]);
					close(pCMD[1]);
				}

				//Redirecionamos stdin
				d = dup2(p[0], 0);
				if(d < 0){
					perror("Erro na duplicação de um descritor");
					kill(getpid(), SIGINT);
				}
				close(p[0]);

				//Esperamos que o filho termine de executar o comando
				wait(&status);

				if(WIFEXITED(status) && WEXITSTATUS(status) > 0){
					perror("Erro na execução do comando.");
         			kill(getpid(), SIGINT);
				}

				//Escrevemos o comando no notebook
				w = write(fd, n->linha, n->tamanho);
				if(w < 0){
					perror("Erro na escrita");
					kill(getpid(), SIGINT);
				}

				//Se o comando estiver for última linha, i.e., não terminar em '\n',
				//é necessário imprimir para evitar conflitos com a zona de resultado
				if(!n->prox && n->linha[n->tamanho - 1] != '\n'){
					char newl = '\n';
					w = write(fd, &newl, 1);
					if(w < 0){
						perror("Erro na escrita");
						kill(getpid(), SIGINT);
					}
				}

				//Iniciamos a zona do resultado
				char abreRes[5] = ">>>\n";
				w = write(fd, &abreRes, 4);
				if(w < 0){
					perror("Erro na escrita");
					kill(getpid(), SIGINT);
				}

				//Obtemos o resultado desse comando
				while((r = readln(0, &linha))){
					if(r < 0){
						perror("Erro na leitura");
						kill(getpid(), SIGINT);
					}

					//Escrevemos o resultado no ficheiro
					w = write(fd, linha, r);

					if(w < 0){
						perror("Erro na escrita");
						kill(getpid(), SIGINT);
					}

					//Adicionamos o resultado à estrutura
					Notebook* res = novoNodo(linha, RES, r, 0, 0);
					pos = n->prox;
					n->prox = res;
					res->prox = pos;
					n = res;
				}

				//Terminamos a zona de resultado
				char fechaRes[5] = "<<<\n";
				w = write(fd, &fechaRes, 4);
				if(w < 0){
					perror("Erro na escrita");
					kill(getpid(), SIGINT);
				}
			}

		}

		//Processeguimos no processamento
		n = n->prox;
	}

	//Libertamos a memória alocada para as estruturas auxiliares
	freeNotebook(&n);
	freeNotebook(&nInic);
}
